To use the mod loader you must place the ZMTLoader folder along the pak files of the game.
Then just run it